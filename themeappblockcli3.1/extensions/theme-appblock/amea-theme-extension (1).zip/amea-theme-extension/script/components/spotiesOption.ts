class SpotiesOption extends HTMLElement {
    validate() {
        return true;
    }
}

export default SpotiesOption;
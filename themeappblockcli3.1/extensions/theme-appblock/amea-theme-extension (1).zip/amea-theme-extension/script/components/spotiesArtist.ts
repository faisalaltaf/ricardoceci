import SpotiesRecord from "./spotiesRecord";

class SpotiesArtist extends SpotiesRecord {
    constructor() {
        super();
        this.update_value = "artists";
    }
}

export default SpotiesArtist;
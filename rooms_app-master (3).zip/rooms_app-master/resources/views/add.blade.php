@extends('vendor.shopify-app.layouts.default') 
@section('content')
  <h3 class="display-3">
    <div class="row">
      <div class="col-md-6">
        <a href="{{ URL::tokenRoute('home') }}" class="btn btn-link-gray page-header__back">
          <svg class="polaris-icon__svg" viewBox="0 0 20 20"><path d="M12 16a.997.997 0 0 1-.707-.293l-5-5a.999.999 0 0 1 0-1.414l5-5a.999.999 0 1 1 1.414 1.414L8.414 10l4.293 4.293A.999.999 0 0 1 12 16" fill-rule="evenodd"></path></svg>
          Rooms
        </a>
      </div>
      <div class="col-md-6 text-right">
        <button typ="button" class="btn btn-primary addProduct">Add Products</button>
      </div>
    </div>
  </h3>
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-body">
          <div class="form-group">
            <label class="col-form-label" for="formGroupExampleInput">Room Name</label>
            <input type="text" class="form-control roomName" id="formGroupExampleInput" placeholder="Awesome Product">
          </div>
        </div>
      </div>
      <div class="card">
          <ul class="resource-list">
            <img src="{{ asset('assets/images/retail.svg') }}" />           
          </ul>
        </div>
    </div>
    <div class="col-md-4">
      <div class="card">
        <div class="card-body">
          <h3>Upload Video</h3>
          <input class="form-control videoFile" type="file" accept=".mp4"/>
        </div>
        <div class="card-body">
          <h3>Add Image</h3>
          <input class="form-control imageFile" type="file" accept=".jpg,.jpeg,.png"/>
        </div>
      </div>
    </div>
  </div>
@endsection
@section('scripts')
  <script>
    $( document ).ready(function() {
      let selectedValues = []
      const ResourcePicker = AppBridge.actions.ResourcePicker;
      const picker = ResourcePicker.create(app, {
        resourceType: ResourcePicker.ResourceType.Product,
        options: {
          showVariants: false,
          initialSelectionIds: selectedValues,
        }
      });
      picker.subscribe(ResourcePicker.Action.SELECT, (payload) => {
        console.log(payload.selection)
        selectedValues = payload.selection.map(i => { 
          return { 
            id : i.id,
            originalSrc: i.images.length ? i.images[0].originalSrc : '',
            title: i.title, 
            createdAt: i.createdAt
          } 
        })
        $('.resource-list').html(createProductList())
        barCheck()
      });
      const contextualSaveBar = actions.ContextualSaveBar.create(app, {
        saveAction: {
          disabled: false,
          loading: false,
        },
        discardAction: {
          disabled: false,
          loading: false
        }
      });
      contextualSaveBar.subscribe(actions.ContextualSaveBar.Action.SAVE,async function() {
        contextualSaveBar.set({saveAction: {loading: true}});
        let token = await utils.getSessionToken(app)
        try {
          let result = await $.ajax({
            processData: false,
            contentType: false,
            url: '{{ route("create") }}',
            type: "POST",
            data: toFormData({
              ids: selectedValues.map((i) => i.id),
              name: $(".roomName").val(),
              file: $('.videoFile').prop('files')[0],
              image: $('.imageFile').prop('files')[0],
              token: token
            })
          });
          const toast = actions.Toast.create(app, {
            message: result.message,
            duration: 2000,
            isError: !result.status ? true : false
          }).dispatch(actions.Toast.Action.SHOW)
        } catch (error) {
          console.log(error);
        }
        contextualSaveBar.set({saveAction: {loading: false}});
        contextualSaveBar.dispatch(actions.ContextualSaveBar.Action.HIDE);
      });
      contextualSaveBar.subscribe(actions.ContextualSaveBar.Action.DISCARD,function() {
          contextualSaveBar.dispatch(actions.ContextualSaveBar.Action.HIDE);
      });
      $('.addProduct').click(function(){
        if(selectedValues.length){
          picker.set({initialSelectionIds: selectedValues });
        }
        picker.dispatch(ResourcePicker.Action.OPEN);
      })
      function createProductList(){
        let html = ``;
        if(selectedValues.length){
          for( let i=0; i<selectedValues.length; i++ ){
            html += `
              <li class="resource-list__item">
                <div class="resource-list__item-owned">
                  <span class="avatar avatar--medium" aria-label="Derek" role="img">
                  <img src="${selectedValues[i].originalSrc}" class="Polaris-Avatar__Image" alt="Avatar image for Derek" role="presentation"></span>
                </div>
                <div class="resource-list__item-content">
                  <h3>${selectedValues[i].title}</h3>
                  <p>${selectedValues[i].createdAt}</p>
                </div>
              </li>
            `;
          }
        }else{
          html +=`<img src="{{ asset('assets/images/retail.svg') }}" />`;
        }
        return html;
      }
      $('.videoFile').change(function(){
        barCheck();
      })
      $('.imageFile').change(function(){
        barCheck();
      })
      $('.roomName').keydown(function(){
        barCheck();
      })
      function barCheck(){
        if(selectedValues.length && $('.videoFile').val() && $('.imageFile').val() && $(".roomName").val()){
          contextualSaveBar.dispatch(actions.ContextualSaveBar.Action.SHOW);
        }else{
          contextualSaveBar.dispatch(actions.ContextualSaveBar.Action.HIDE);
        }
      }
      function toFormData(data){
        var form_data = new FormData();
        for ( var key in data ) {
          if(typeof data[key] === 'object'){
            if(data[key].length){
              for (var i = 0; i < data[key].length; i++) {
                form_data.append(`${key}[]`, data[key][i]);
              }
            }else{
              form_data.append(key, data[key]);
            }
          }else{
            form_data.append(key, data[key]);
          }
        }
        return form_data
      }
    });
    
  </script>
@endsection

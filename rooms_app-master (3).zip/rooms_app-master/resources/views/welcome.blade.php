@extends('vendor.shopify-app.layouts.default') 
@section('content')
  <div class="row no-gutters">
    <div class="col-md-12">
      <h3 class="display-3">
        <div class="row">
          <div class="col-md-6">Rooms</div>
          <div class="col-md-6 text-right">
            <a href="{{ URL::tokenRoute('add') }}" class="btn btn-primary">Create Room</a>
          </div>
        </div>
      
      </h3>
      <section class="card">
        <div class="card-body">
          <table class="table table-responsive">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Room Name</th>
                <th scope="col">Room Image</th>
                <th scope="col">Date Created</th>
                <th scope="col">Date Updated</th>
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody>
              @forelse ($rooms as $room)
                <tr>
                  <th scope="row">{{ ++$loop->index }}</th>
                  <td>{{ $room->name }}</td>
                  <td><img src="{{ asset('storage/'.$room->image) }}"/> </td>
                  <td>{{ $room->created_at->format('Y-m-d') }}</td>
                  <td>{{ $room->updated_at->format('Y-m-d') }}</td>
                  <td></td>
                </tr>
              @empty
                <tr>
                  <td colspan="5" class="text-center">
                    <img class="d-inline" src="{{ asset('assets/images/retail.svg') }}" />
                  </td>
                </tr>
              @endforelse
            </tbody>
          </table>
        </div>
      </section>
    </div>
  </div>
@endsection

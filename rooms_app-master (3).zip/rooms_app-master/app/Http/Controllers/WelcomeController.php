<?php

namespace App\Http\Controllers;

use App\Models\Room;
use App\Models\RoomProduct;
use Illuminate\Http\Request;
use App\Http\Traits\LVHTrait;
use Illuminate\Support\Facades\DB;

class WelcomeController extends Controller
{
    use LVHTrait;

    public function index(){
        $rooms = Room::UserRooms()->paginate(10);
        return view('welcome',compact('rooms'));
    }

    public function addRoom(){
        return view("add");
    }

    public function createRoom(){
        $validated = $this->validation(['Room.Create']);
        if (!is_array($validated)) :
            return $validated;
        endif;
        DB::beginTransaction();
        $room = Room::create([
            "name" => request('name'),
            "video" => request('file')->store('rooms/videos'),
            "image" => request('image')->store('rooms/images'),
            "user_id" => auth()->user()->id
        ]);
        $inserted = RoomProduct::insert(collect(request('ids'))->map(fn ($p) => [
            "room_id" => $room->id,
            "shopify_product_id" => $p,
            "created_at" => now(),
            "updated_at" => now()
        ])->toArray());
        if($room && $inserted) :
            DB::commit();
            return response([
                "status" =>  true,
                "message" => 'Room Created Successfully.'
            ],201);
        else:
            DB::rollBack();
            return response([
                "status" =>  false,
                "message" => 'Something Went Wrong.'
            ],500);
        endif;

    }
}

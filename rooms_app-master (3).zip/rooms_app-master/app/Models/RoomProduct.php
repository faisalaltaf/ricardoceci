<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RoomProduct extends Model
{
    use HasFactory;

    protected $fillable = [
        'room_id',
        'shopify_product_id',
    ];
}

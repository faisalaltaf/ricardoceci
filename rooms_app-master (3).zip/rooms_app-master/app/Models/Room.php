<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\RoomProduct;
use Illuminate\Database\Eloquent\Builder;

class Room extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'video',
        'image',
        'user_id'
    ];

    public function products(){
        return $this->hasMany(RoomProduct::class);
    }

    public function scopeUserRooms(Builder $query): void
    {
        $query->where('user_id', auth()->user()->id);
    }
}
